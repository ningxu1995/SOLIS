# Representative raw sequences

This directory is reserved for a small, de-identified subset of the original
camera data that is sufficient to demonstrate the published processing path.
Synthetic data must never be placed in `raw/` or described as representative
experimental data.

## Minimum experimental deposit

The repository should contain, at minimum:

1. `raw/cilia_representative_raw.tif`
   - label-free ciliary acquisition used for a representative reconstruction;
   - TIFF axes: `(frame, y, x)`;
   - consecutive groups of 25 frames form one SOLIS map;
   - uint16 camera counts, before background subtraction or flat-fielding.
2. `raw/line_pair_270nm_raw.tif`
   - one or more 25-address cycles from the 270 nm line-pair target.
3. `raw/probe_calibration_raw.tif`
   - address-resolved focal-plane calibration frames used to estimate gains.
4. `calibration/dark_frame.tif`
   - mean or address-resolved dark measurement acquired under matched camera
     gain and exposure.
5. `calibration/flat_field.tif`
   - flat-field image used by the reconstruction.
6. `calibration/address_gains.csv`
   - columns `address,gain`; exactly 25 rows in acquisition order.
7. `calibration/address_shifts.csv`
   - columns `address,shift_y_pixels,shift_x_pixels`; exactly 25 rows.

Adding one control and one Dynarrestin-treated raw sequence is strongly
recommended for reproducing the CBF workflow. If file size is restrictive,
deposit these sequences on Zenodo and retain the same relative paths in the
manifest.

## Required companion metadata

Each raw TIFF must have a JSON file with the same stem, following
`metadata.template.json`. The metadata must state whether the sequence is
experimental or synthetic, the sample type, acquisition date, exposure,
address order, number of cycles, camera ROI, and the manuscript figure(s) that
use the sequence. Human-derived samples must remain de-identified.

## Raw-data rule

Raw TIFF files must contain the original camera counts. Do not apply contrast
stretching, normalization, denoising, Gaussian filtering, interpolation, or
coordinate reassignment before deposit. Derived images belong in `processed/`.

## Validation

After adding the files, run:

```bash
python scripts/validate_representative_data.py \
  --manifest example_data/representative_sequences_manifest.csv
```

The validator checks file existence, SHA-256 hashes, TIFF dimensionality, and
whether the frame count is divisible by 25.
