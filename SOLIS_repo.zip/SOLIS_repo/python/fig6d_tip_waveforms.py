#!/usr/bin/env python3
"""Plot the Fig. 6d control and Dynarrestin tip waveforms.

The input workbook contains phase-averaged, beat-axis-aligned tip coordinates
for eight control and eight Dynarrestin-treated cilia. It is processed source
data, not a raw camera sequence.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


CONTROL_COLOR = "#729ece"
DYNARRESTIN_COLOR = "#d65f5f"
REQUIRED_COLUMNS = {
    "Condition",
    "Cilium_ID",
    "phase",
    "x_phase_um",
    "y_phase_um",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("source_data/fig6/fig6d_phase_averaged_trajectories.xlsx"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("outputs/fig6d_tip_waveforms.png"),
    )
    parser.add_argument("--dpi", type=int, default=500)
    return parser.parse_args()


def validate_source_data(data: pd.DataFrame) -> None:
    missing = REQUIRED_COLUMNS.difference(data.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if data[list(REQUIRED_COLUMNS)].isna().any().any():
        raise ValueError("The Fig. 6d source-data table contains missing values")
    expected_conditions = {"Control", "Dynarrestin"}
    observed_conditions = set(data["Condition"].unique())
    if observed_conditions != expected_conditions:
        raise ValueError(
            f"Expected conditions {sorted(expected_conditions)}, found "
            f"{sorted(observed_conditions)}"
        )
    counts = data.groupby(["Condition", "Cilium_ID"]).size()
    if counts.nunique() != 1:
        raise ValueError("All cilia must have the same number of phase samples")


def despine(axis: plt.Axes) -> None:
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)


def main() -> None:
    args = parse_args()
    data = pd.read_excel(args.input)
    validate_source_data(data)

    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 11,
            "axes.linewidth": 0.6,
            "axes.edgecolor": "#3a3d42",
            "xtick.major.width": 0.6,
            "ytick.major.width": 0.6,
            "xtick.major.size": 2.5,
            "ytick.major.size": 2.5,
        }
    )

    fig, axis = plt.subplots(figsize=(3.5, 3.5))
    despine(axis)

    for condition, color in (
        ("Control", CONTROL_COLOR),
        ("Dynarrestin", DYNARRESTIN_COLOR),
    ):
        subset = data[data["Condition"] == condition]
        for _, trajectory in subset.groupby("Cilium_ID"):
            trajectory = trajectory.sort_values("phase")
            x = trajectory["x_phase_um"].to_numpy()
            y = trajectory["y_phase_um"].to_numpy()
            axis.plot(
                np.r_[x, x[0]],
                np.r_[y, y[0]],
                color=color,
                linewidth=0.5,
                alpha=0.32,
            )

        x_by_phase = subset.pivot_table(
            index="phase", columns="Cilium_ID", values="x_phase_um"
        ).sort_index()
        y_by_phase = subset.pivot_table(
            index="phase", columns="Cilium_ID", values="y_phase_um"
        ).sort_index()
        mean_x = x_by_phase.mean(axis=1).to_numpy()
        mean_y = y_by_phase.mean(axis=1).to_numpy()
        axis.plot(
            np.r_[mean_x, mean_x[0]],
            np.r_[mean_y, mean_y[0]],
            color=color,
            linewidth=2.6,
            label=condition,
            zorder=5,
        )

    axis.set_ylim(-1.6, 1.6)
    axis.set_yticks([1.5, 0.5, -0.5, -1.5])
    axis.set_box_aspect(1.0)
    axis.set_xlabel("along beat axis (µm)")
    axis.set_ylabel("transverse (µm)")
    axis.set_title("Tip waveform", fontsize=11.5)
    axis.legend(frameon=False, fontsize=9, handlelength=1.2)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=args.dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
