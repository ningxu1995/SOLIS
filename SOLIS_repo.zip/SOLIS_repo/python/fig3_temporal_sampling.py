#!/usr/bin/env python3
"""
Standalone simulation for SOLIS Figure 3c: Simulated tip-trajectory recovery.

This script isolates the acquisition-level digital twin to simulate a single beat 
cycle of a moving cilium. It compares the instantaneous mathematical truth, 
the cycle-averaged centroid reference, the noisy SOLIS reconstruction, and 
a standard 24 fps widefield sampling control.

Usage:
    python fig3c_trajectory.py
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.signal import fftconvolve

# --- Color Palette ---
BLUE = "#1769AA"
ORANGE = "#D95F02"
CHARCOAL = "#242424"
MID_GREY = "#777777"


@dataclass(frozen=True)
class Acquisition:
    pixel_um: float = 0.087
    grid_size: int = 96
    exposure_s: float = 143e-6
    n_addresses: int = 25
    scan_side: int = 5
    probe_fwhm_um: float = 0.224
    widefield_fwhm_um: float = 0.360
    sidelobe_radius_um: float = 0.47
    sidelobe_sbr: float = 5.3
    probe_cv: float = 0.071
    flatfield_residual_cv: float = 0.010
    background_e: float = 12.0
    read_noise_e: float = 2.2
    nominal_snr: float = 10.0
    cilium_fwhm_um: float = 0.20

    @property
    def cycle_s(self) -> float:
        return self.exposure_s * self.n_addresses

    @property
    def frame_rate(self) -> float:
        return 1.0 / self.cycle_s


@dataclass(frozen=True)
class Waveform:
    frequency_hz: float = 19.2
    stroke_amplitude_um: float = 4.8
    loop_height_um: float = 1.65
    effective_fraction: float = 0.34
    bend_um: float = 0.55
    orientation_rad: float = 0.0
    contrast: float = 0.85


# --- Kinematic Models ---

def smoothstep(u: np.ndarray | float) -> np.ndarray | float:
    u = np.clip(u, 0.0, 1.0)
    return u * u * (3.0 - 2.0 * u)


def geometric_phase(phase: np.ndarray | float, effective_fraction: float):
    p = np.mod(phase, 1.0)
    first = p < effective_fraction
    q = np.empty_like(np.asarray(p, dtype=float))
    u1 = np.asarray(p, dtype=float) / effective_fraction
    u2 = (np.asarray(p, dtype=float) - effective_fraction) / (1.0 - effective_fraction)
    q[first] = np.pi * smoothstep(u1[first])
    q[~first] = np.pi + np.pi * smoothstep(u2[~first])
    if np.ndim(phase) == 0:
        return float(q)
    return q


def rotate_xy(xy: np.ndarray, angle: float, origin: np.ndarray) -> np.ndarray:
    c, s = np.cos(angle), np.sin(angle)
    rot = np.array([[c, -s], [s, c]])
    return (xy - origin) @ rot.T + origin


def cilium_centerline(phase: float, wf: Waveform, n: int = 240) -> np.ndarray:
    q = geometric_phase(phase, wf.effective_fraction)
    base = np.array([0.0, -3.15])
    tip = np.array(
        [
            0.5 * wf.stroke_amplitude_um * np.cos(q),
            1.55 + 0.5 * wf.loop_height_um * np.sin(q) + 0.12 * np.sin(2.0 * q),
        ]
    )
    bend = wf.bend_um * np.sin(q + 0.45)
    p1 = np.array([0.14 * tip[0] - 0.35 * bend, -1.65 + 0.08 * np.cos(q)])
    p2 = np.array([0.70 * tip[0] + 0.55 * bend, 0.58 + 0.25 * np.sin(q)])
    u = np.linspace(0.0, 1.0, n)[:, None]
    curve = (
        (1 - u) ** 3 * base
        + 3 * (1 - u) ** 2 * u * p1
        + 3 * (1 - u) * u**2 * p2
        + u**3 * tip
    )
    if wf.orientation_rad:
        curve = rotate_xy(curve, wf.orientation_rad, base)
    return curve


def cilium_tip(phase: np.ndarray | float, wf: Waveform) -> np.ndarray:
    phases = np.atleast_1d(phase)
    out = np.stack([cilium_centerline(float(p), wf, n=3)[-1] for p in phases])
    return out[0] if np.ndim(phase) == 0 else out


def average_tip(start_s: float, wf: Waveform, acq: Acquisition, n: int = 41) -> np.ndarray:
    t = start_s + np.linspace(0, acq.cycle_s, n, endpoint=False) + acq.cycle_s / (2 * n)
    return np.mean(cilium_tip((t * wf.frequency_hz) % 1, wf), axis=0)


# --- Optics and Imaging Models ---

def physical_grid(acq: Acquisition) -> tuple[np.ndarray, np.ndarray]:
    half = acq.pixel_um * (acq.grid_size - 1) / 2
    axis = np.linspace(-half, half, acq.grid_size)
    return np.meshgrid(axis, axis)


def bilinear_deposit(image: np.ndarray, xpix: np.ndarray, ypix: np.ndarray) -> None:
    h, w = image.shape
    x0 = np.floor(xpix).astype(int)
    y0 = np.floor(ypix).astype(int)
    dx = xpix - x0
    dy = ypix - y0
    for ox, oy, weight in (
        (0, 0, (1 - dx) * (1 - dy)),
        (1, 0, dx * (1 - dy)),
        (0, 1, (1 - dx) * dy),
        (1, 1, dx * dy),
    ):
        xi, yi = x0 + ox, y0 + oy
        valid = (xi >= 0) & (xi < w) & (yi >= 0) & (yi < h)
        np.add.at(image, (yi[valid], xi[valid]), weight[valid])


def render_cilium(phase: float, wf: Waveform, acq: Acquisition) -> np.ndarray:
    curve = cilium_centerline(phase, wf)
    half = acq.pixel_um * (acq.grid_size - 1) / 2
    xpix = (curve[:, 0] + half) / acq.pixel_um
    ypix = (curve[:, 1] + half) / acq.pixel_um
    image = np.zeros((acq.grid_size, acq.grid_size), dtype=float)
    bilinear_deposit(image, xpix, ypix)
    
    tip_image = np.zeros_like(image)
    bilinear_deposit(tip_image, xpix[-1:], ypix[-1:])
    image += 8.0 * tip_image
    
    sigma_px = acq.cilium_fwhm_um / (2.355 * acq.pixel_um)
    image = gaussian_filter(image, sigma=max(sigma_px, 0.45), mode="constant")
    if image.max() > 0:
        image /= image.max()
    return wf.contrast * image


def analytic_probe(acq: Acquisition) -> np.ndarray:
    x, y = physical_grid(acq)
    r = np.hypot(x, y)
    sigma = acq.probe_fwhm_um / 2.355
    central = np.exp(-0.5 * (r / sigma) ** 2)
    ring_sigma = 0.075
    ring_peak = 1.0 / acq.sidelobe_sbr
    ring = ring_peak * np.exp(-0.5 * ((r - acq.sidelobe_radius_um) / ring_sigma) ** 2)
    probe = np.clip(central + ring, 0, None)
    probe /= probe.sum()
    return probe


def sampled_pixels_for_shift(
    shape: tuple[int, int], shift: tuple[int, int], side: int
) -> tuple[np.ndarray, np.ndarray]:
    sx, sy = shift
    yy, xx = np.mgrid[sy : shape[0] : side, sx : shape[1] : side]
    return yy, xx


def acquisition_signal(
    start_s: float,
    wf: Waveform,
    acq: Acquisition,
    probe: np.ndarray,
    gains: np.ndarray,
    scan_order: np.ndarray,
) -> dict[str, np.ndarray]:
    signal = np.zeros((acq.grid_size, acq.grid_size), dtype=float)
    gain_map = np.ones_like(signal)
    ideal = np.zeros_like(signal)
    
    for n, (sx, sy) in enumerate(scan_order):
        t = start_s + (n + 0.5) * acq.exposure_s
        phase = (t * wf.frequency_hz) % 1.0
        obj = render_cilium(phase, wf, acq)
        blurred = fftconvolve(obj, probe, mode="same")
        yy, xx = sampled_pixels_for_shift(
            signal.shape, (int(sx), int(sy)), acq.scan_side
        )
        signal[yy, xx] = blurred[yy, xx]
        # The measured non-uniformity is address specific: all detector samples
        # acquired at address n receive the same gain g_n.
        gain_map[yy, xx] = gains[n]
        ideal += blurred / acq.n_addresses
        
    return {
        "signal": signal,
        "gain_map": gain_map,
        "ideal": ideal,
    }


def peak_electrons_for_snr(snr: float, background: float, read_noise: float) -> float:
    s2 = snr * snr
    return 0.5 * (s2 + math.sqrt(s2 * s2 + 4 * s2 * (background + read_noise**2)))


def noisy_reconstruction(
    deterministic: dict[str, np.ndarray],
    acq: Acquisition,
    snr: float,
    rng: np.random.Generator,
    calibration_residual: np.ndarray,
) -> np.ndarray:
    signal = deterministic["signal"]
    gain = deterministic["gain_map"]
    peak = peak_electrons_for_snr(snr, acq.background_e, acq.read_noise_e)
    scale = max(np.percentile(signal[signal > 0], 99.8), 1e-12)
    unit_signal = np.clip(signal / scale, 0, None)
    
    lam = acq.background_e + peak * gain * unit_signal
    detected = rng.poisson(np.clip(lam, 0, None)) + rng.normal(0, acq.read_noise_e, signal.shape)
    corrected_gain = np.clip(gain * calibration_residual, 0.2, None)
    recon = (detected - acq.background_e) / (peak * corrected_gain)
    return np.clip(recon, 0, None)


def track_tip(image: np.ndarray, predicted_tip: np.ndarray, acq: Acquisition, radius_um: float = 0.54) -> np.ndarray:
    image = gaussian_filter(image, 0.6, mode="nearest")
    x, y = physical_grid(acq)
    roi = (x - predicted_tip[0]) ** 2 + (y - predicted_tip[1]) ** 2 <= radius_um**2
    values = image[roi].astype(float)
    
    if values.size == 0 or not np.isfinite(values).any():
        return np.array([np.nan, np.nan])
        
    background = np.percentile(values, 15)
    weights = np.clip(values - background, 0, None)
    
    window_sigma_um = 0.24
    window = np.exp(
        -0.5
        * ((x[roi] - predicted_tip[0]) ** 2 + (y[roi] - predicted_tip[1]) ** 2)
        / window_sigma_um**2
    )
    weights *= window
    cutoff = 0.12 * weights.max() if weights.max() > 0 else np.inf
    weights[weights < cutoff] = 0
    
    if weights.sum() <= 0:
        return predicted_tip.copy()
    return np.array([np.sum(x[roi] * weights) / weights.sum(), np.sum(y[roi] * weights) / weights.sum()])


def clean_axis(ax: mpl.axes.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(length=3, width=0.8)


def main():
    parser = argparse.ArgumentParser(description="Generate Fig 3c tip-trajectory panel.")
    parser.add_argument("--output", type=Path, default=Path("Fig3c_tip_trajectory.png"))
    parser.add_argument(
        "--source-data",
        type=Path,
        default=Path("source_data/fig3/fig3c_simulated_trajectories.csv"),
        help="Long-format simulated coordinates used for the plotted curves.",
    )
    parser.add_argument(
        "--metadata",
        type=Path,
        default=Path("source_data/fig3/fig3c_simulation_metadata.json"),
    )
    parser.add_argument("--seed", type=int, default=20260710)
    parser.add_argument("--dpi", type=int, default=300)
    args = parser.parse_args()

    print("Initializing digital twin parameters...")
    acq = Acquisition()
    wf = Waveform()
    rng = np.random.default_rng(args.seed)

    # 1. Prepare simulated optics and scan patterns
    probe = analytic_probe(acq)
    raw_gains = rng.normal(1.0, acq.probe_cv, acq.n_addresses)
    gains = raw_gains / raw_gains.mean()
    residual = rng.normal(1.0, acq.flatfield_residual_cv, (acq.grid_size, acq.grid_size))

    # Standard 5x5 serpentine scan order
    order = []
    for iy in range(acq.scan_side):
        xs: Iterable[int] = range(acq.scan_side) if iy % 2 == 0 else range(acq.scan_side - 1, -1, -1)
        order.extend((ix, iy) for ix in xs)
    scan_order = np.asarray(order, dtype=int)

    # 2. Simulate SOLIS tracking over one beat period
    print("Simulating trajectory recovery...")
    period = 1.0 / wf.frequency_hz
    starts = np.arange(0, period, acq.cycle_s)
    recovered_traj, averaged_truth = [], []
    
    for st in starts:
        d = acquisition_signal(st, wf, acq, probe, gains, scan_order)
        geometric = average_tip(st, wf, acq)
        tr = track_tip(d["ideal"], geometric, acq)
        im = noisy_reconstruction(d, acq, acq.nominal_snr, rng, residual)
        
        recovered_traj.append(track_tip(im, geometric, acq))
        averaged_truth.append(tr)
        
    recovered_traj = np.asarray(recovered_traj)
    averaged_truth = np.asarray(averaged_truth)

    # 3. Generate ground truth and standard limits
    print("Computing instantaneous and widefield references...")
    dense_phase = np.linspace(0, 1, 500, endpoint=False)
    dense_tip = cilium_tip(dense_phase, wf)

    wide_starts = np.arange(0, period, 1 / 24.0)
    # This is temporal downsampling of the same simulated trajectory, not a
    # model of a 24-fps camera exposure. Each point is an instantaneous sample.
    wide_points = cilium_tip((wide_starts * wf.frequency_hz) % 1, wf)

    source_rows: list[dict[str, float | int | str]] = []
    for series, coordinates in (
        ("instantaneous_truth", dense_tip),
        ("cycle_averaged_centroid_reference", averaged_truth),
        ("solis_recovered", recovered_traj),
        ("24_fps_temporal_samples", wide_points),
    ):
        for index, (x_um, y_um) in enumerate(coordinates):
            source_rows.append(
                {
                    "series": series,
                    "sample_index": index,
                    "x_um": float(x_um),
                    "y_um": float(y_um),
                }
            )

    args.source_data.parent.mkdir(parents=True, exist_ok=True)
    with args.source_data.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["series", "sample_index", "x_um", "y_um"]
        )
        writer.writeheader()
        writer.writerows(source_rows)

    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    metadata = {
        "data_type": "simulation",
        "seed": args.seed,
        "acquisition": asdict(acq),
        "waveform": asdict(wf),
        "scan_order_xy": scan_order.tolist(),
        "control_definition": (
            "Instantaneous samples of the same simulated trajectory at 24 fps; "
            "no camera-exposure integration was applied."
        ),
    }
    args.metadata.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    # 4. Plotting
    print(f"Generating figure at {args.output}...")
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 11,
            "axes.linewidth": 0.8,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
        }
    )

    fig, ax_c = plt.subplots(figsize=(6, 5.5), facecolor="white")
    
    ax_c.plot(dense_tip[:, 0], dense_tip[:, 1], color=CHARCOAL, lw=1.3, label="Instantaneous truth")
    ax_c.plot(averaged_truth[:, 0], averaged_truth[:, 1], color=MID_GREY, lw=1.0, marker="o", ms=4.0, mfc="white", label="3.58 ms centroid reference")
    ax_c.plot(recovered_traj[:, 0], recovered_traj[:, 1], color=BLUE, lw=1.5, marker="o", ms=4.2, label="SOLIS recovered")
    ax_c.scatter(wide_points[:, 0], wide_points[:, 1], color=ORANGE, s=45, marker="s", label="24 fps sampling control", zorder=5)
    
    ax_c.set_aspect("equal", adjustable="datalim")
    ax_c.set_xlabel("x position (μm)")
    ax_c.set_ylabel("y position (μm)")
    ax_c.set_title("Simulated tip-trajectory recovery", fontsize=13, pad=12, fontweight="bold")
    
    # Legend adjusted for single-plot layout
    ax_c.legend(frameon=False, fontsize=9.5, loc="lower center", bbox_to_anchor=(0.5, -0.32), ncol=2, handlelength=1.5, columnspacing=1.0)
    clean_axis(ax_c)
    
    plt.tight_layout()
    fig.subplots_adjust(bottom=0.25) # Make room for legend
    
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=args.dpi, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"Saved source data to {args.source_data}")
    print(f"Saved simulation metadata to {args.metadata}")
    print("Done.")


if __name__ == "__main__":
    main()
