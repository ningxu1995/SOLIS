# Figure 6d processed source data

`fig6d_phase_averaged_trajectories.xlsx` contains the plotted coordinates for
the tip-waveform panel only. It is **processed source data**, not a raw camera
sequence and not the complete source data for Fig. 6.

## Columns

| Column | Meaning |
|---|---|
| `Condition` | `Control` or `Dynarrestin` |
| `Cilium_ID` | Cilium identifier within condition |
| `phase` | Normalised beat phase |
| `x_phase_um` | Phase-averaged coordinate along the beat axis, in µm |
| `y_phase_um` | Phase-averaged transverse coordinate, in µm |

The workbook contains eight cilia per condition and 120 phase samples per
cilium. The plotting script does not perform tip tracking, phase estimation,
coordinate alignment, or statistical testing.

Before archival release, add culture, field-of-view, and donor or biological-
replicate identifiers, or provide a companion provenance table that maps every
`Condition` and `Cilium_ID` pair to those identifiers.

Run from the repository root:

```bash
python python/fig6d_tip_waveforms.py
```
