# Figure 3c simulation source data

Figure 3c is an acquisition-level simulation, not experimental validation.
Running `python/fig3_temporal_sampling.py` writes:

- `fig3c_simulated_trajectories.csv`, containing the coordinates plotted for
  the instantaneous trajectory, 3.58 ms centroid reference, SOLIS recovery,
  and 24 fps temporal samples;
- `fig3c_simulation_metadata.json`, containing the random seed, scan order,
  acquisition settings, waveform settings, and the definition of the 24 fps
  control.

The address-to-address gain term is applied once per DMD address. The 24 fps
control consists of instantaneous temporal samples of the same simulated
trajectory and is not intended to represent exposure-integrated widefield
camera data.

Run from the repository root:

```bash
python python/fig3_temporal_sampling.py
```
