# Legacy and unverified files

Files in this directory are retained for provenance only and are not part of
the reproducible analysis release.

Some historical figure scripts contain interpolated, illustrative, or explicit
placeholder values and refer to earlier manuscript figure numbering. They must
not be used to generate source data or final manuscript figures unless every
input is replaced with the corresponding experimental measurement and the
output is independently checked.

The current script-to-figure status is maintained in
`docs/SCRIPT_TO_FIGURE.md`.
