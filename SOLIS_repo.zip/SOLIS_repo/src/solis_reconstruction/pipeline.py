"""End-to-end, auditable SOLIS reconstruction pipeline."""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy.ndimage import gaussian_filter
import tifffile

from .config import ReconstructionConfig
from .io import read_array, read_raw_stack, read_shifts, read_vector, sha256_file, write_json, write_tiff
from .preprocess import preprocess_cycle
from .reconstruct import interlace_cycle


def _optional_array(path: str | None) -> np.ndarray | None:
    return None if path is None else np.asarray(read_array(path), dtype=np.float32)


def reconstruct_file(config: ReconstructionConfig) -> dict[str, str]:
    """Run reconstruction and return paths to generated artifacts."""
    config.validate()
    raw_path = Path(config.input_file)
    if not raw_path.exists():
        raise FileNotFoundError(raw_path)
    raw = read_raw_stack(raw_path, config.addresses_per_cycle)

    dark_frame = _optional_array(config.background.dark_frame)
    flat_field = _optional_array(config.calibration.flat_field)
    gains = (
        None
        if config.calibration.address_gains is None
        else read_vector(config.calibration.address_gains, config.addresses_per_cycle)
    )
    shifts = (
        None
        if config.calibration.address_shifts is None
        else read_shifts(config.calibration.address_shifts, config.addresses_per_cycle)
    )

    unfiltered: list[np.ndarray] = []
    qc_rows: list[dict[str, float | int]] = []
    for cycle_index, cycle in enumerate(raw):
        corrected = preprocess_cycle(
            cycle,
            background_mode=config.background.mode,
            dark_frame=dark_frame,
            background_constant=config.background.constant,
            border_width=config.background.border_width,
            flat_field=flat_field,
            address_gains=gains,
            address_shifts=shifts,
            clip_negative=config.clip_negative,
        )
        reconstructed = interlace_cycle(corrected, config.address_offsets, config.scan_shape)
        unfiltered.append(reconstructed)
        qc_rows.append(
            {
                "cycle": cycle_index,
                "raw_min": float(np.min(cycle)),
                "raw_max": float(np.max(cycle)),
                "raw_mean": float(np.mean(cycle)),
                "reconstructed_min": float(np.min(reconstructed)),
                "reconstructed_max": float(np.max(reconstructed)),
                "reconstructed_mean": float(np.mean(reconstructed)),
                "zero_fraction": float(np.mean(reconstructed == 0)),
            }
        )

    unfiltered_stack = np.stack(unfiltered).astype(np.float32)
    sigma = config.filtering.gaussian_sigma_pixels
    if sigma > 0:
        filtered_stack = np.stack(
            [gaussian_filter(frame, sigma=sigma, mode="nearest") for frame in unfiltered_stack]
        ).astype(np.float32)
    else:
        filtered_stack = unfiltered_stack.copy()

    output_dir = Path(config.output.directory)
    output_dir.mkdir(parents=True, exist_ok=True)
    prefix = config.output.prefix
    outputs: dict[str, str] = {}

    filtered_path = output_dir / f"{prefix}_reconstructed.tif"
    write_tiff(filtered_path, filtered_stack, config.output.pixel_size_nm)
    outputs["reconstructed"] = str(filtered_path)

    if config.filtering.save_unfiltered:
        unfiltered_path = output_dir / f"{prefix}_reconstructed_unfiltered.tif"
        write_tiff(unfiltered_path, unfiltered_stack, config.output.pixel_size_nm)
        outputs["reconstructed_unfiltered"] = str(unfiltered_path)

    if config.output.write_qc_csv:
        qc_path = output_dir / f"{prefix}_qc.csv"
        with qc_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(qc_rows[0]))
            writer.writeheader()
            writer.writerows(qc_rows)
        outputs["qc"] = str(qc_path)

    if config.output.write_metadata_json:
        calibration_hashes = {}
        for name, path in {
            "dark_frame": config.background.dark_frame,
            "flat_field": config.calibration.flat_field,
            "address_gains": config.calibration.address_gains,
            "address_shifts": config.calibration.address_shifts,
        }.items():
            if path:
                calibration_hashes[name] = sha256_file(path)
        metadata = {
            "pipeline": "solis-reconstruction",
            "pipeline_version": "0.1.0",
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "input_file": str(raw_path.resolve()),
            "input_sha256": sha256_file(raw_path),
            "input_shape_cycle_address_y_x": list(raw.shape),
            "output_shape_time_y_x": list(filtered_stack.shape),
            "calibration_sha256": calibration_hashes,
            "configuration": config.to_dict(),
            "software": {
                "python": sys.version,
                "platform": platform.platform(),
                "numpy": np.__version__,
                "scipy": scipy.__version__,
                "tifffile": tifffile.__version__,
            },
            "processing_statement": (
                "Coordinate reassignment only; no deconvolution, regularisation, "
                "learning-based restoration, or synthesis of unmeasured structure."
            ),
        }
        metadata_path = output_dir / f"{prefix}_metadata.json"
        write_json(metadata_path, metadata)
        outputs["metadata"] = str(metadata_path)

    return outputs
