"""Coordinate-reassignment reconstruction for SOLIS acquisitions.

The package implements the processing steps described in the manuscript:
background subtraction, flat-field and address-gain correction, optional
registration, 5 x 5 coordinate reassignment, and optional light Gaussian
filtering. It does not perform deconvolution or synthesize unmeasured data.
"""

from .config import ReconstructionConfig, load_config
from .pipeline import reconstruct_file
from .reconstruct import interlace_cycle, reconstruct_stack

__all__ = [
    "ReconstructionConfig",
    "interlace_cycle",
    "load_config",
    "reconstruct_file",
    "reconstruct_stack",
]

__version__ = "0.1.0"
