"""Configuration model for the SOLIS reconstruction pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
from typing import Any


def serpentine_offsets(rows: int = 5, columns: int = 5) -> list[list[int]]:
    """Return acquisition-order offsets for a row-wise serpentine scan."""
    offsets: list[list[int]] = []
    for row in range(rows):
        columns_iter = range(columns) if row % 2 == 0 else range(columns - 1, -1, -1)
        offsets.extend([[row, column] for column in columns_iter])
    return offsets


@dataclass
class BackgroundConfig:
    mode: str = "dark_frame"
    dark_frame: str | None = None
    constant: float = 0.0
    border_width: int = 2


@dataclass
class CalibrationConfig:
    flat_field: str | None = None
    address_gains: str | None = None
    address_shifts: str | None = None


@dataclass
class FilterConfig:
    gaussian_sigma_pixels: float = 0.6
    save_unfiltered: bool = True


@dataclass
class OutputConfig:
    directory: str = "example_data/processed"
    prefix: str = "solis"
    pixel_size_nm: float = 87.0
    write_qc_csv: bool = True
    write_metadata_json: bool = True


@dataclass
class ReconstructionConfig:
    input_file: str
    addresses_per_cycle: int = 25
    scan_shape: list[int] = field(default_factory=lambda: [5, 5])
    address_offsets: list[list[int]] = field(default_factory=serpentine_offsets)
    input_axes: str = "AYX"
    clip_negative: bool = True
    background: BackgroundConfig = field(default_factory=BackgroundConfig)
    calibration: CalibrationConfig = field(default_factory=CalibrationConfig)
    filtering: FilterConfig = field(default_factory=FilterConfig)
    output: OutputConfig = field(default_factory=OutputConfig)

    def validate(self) -> None:
        if self.addresses_per_cycle <= 0:
            raise ValueError("addresses_per_cycle must be positive")
        if len(self.scan_shape) != 2 or min(self.scan_shape) <= 0:
            raise ValueError("scan_shape must contain two positive integers")
        if self.scan_shape[0] * self.scan_shape[1] != self.addresses_per_cycle:
            raise ValueError("scan_shape product must equal addresses_per_cycle")
        if len(self.address_offsets) != self.addresses_per_cycle:
            raise ValueError("address_offsets must contain one [row, column] pair per address")
        if len({tuple(offset) for offset in self.address_offsets}) != self.addresses_per_cycle:
            raise ValueError("address_offsets must be unique")
        for row, column in self.address_offsets:
            if not (0 <= row < self.scan_shape[0] and 0 <= column < self.scan_shape[1]):
                raise ValueError(f"address offset {[row, column]} is outside scan_shape")
        if self.background.mode not in {"dark_frame", "border_median", "constant", "none"}:
            raise ValueError("background.mode must be dark_frame, border_median, constant, or none")
        if self.background.mode == "dark_frame" and not self.background.dark_frame:
            raise ValueError("background.dark_frame is required when background.mode is dark_frame")
        if self.filtering.gaussian_sigma_pixels < 0:
            raise ValueError("gaussian_sigma_pixels cannot be negative")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _resolve_optional_path(value: str | None, base: Path) -> str | None:
    if value is None:
        return None
    path = Path(value)
    return str(path if path.is_absolute() else (base / path).resolve())


def load_config(path: str | Path) -> ReconstructionConfig:
    """Load JSON configuration and resolve all paths relative to the config file."""
    config_path = Path(path).resolve()
    data = json.loads(config_path.read_text(encoding="utf-8"))
    base = config_path.parent

    background = BackgroundConfig(**data.pop("background", {}))
    calibration = CalibrationConfig(**data.pop("calibration", {}))
    filtering = FilterConfig(**data.pop("filtering", {}))
    output = OutputConfig(**data.pop("output", {}))
    config = ReconstructionConfig(
        background=background,
        calibration=calibration,
        filtering=filtering,
        output=output,
        **data,
    )

    config.input_file = _resolve_optional_path(config.input_file, base) or config.input_file
    config.background.dark_frame = _resolve_optional_path(config.background.dark_frame, base)
    config.calibration.flat_field = _resolve_optional_path(config.calibration.flat_field, base)
    config.calibration.address_gains = _resolve_optional_path(config.calibration.address_gains, base)
    config.calibration.address_shifts = _resolve_optional_path(config.calibration.address_shifts, base)
    config.output.directory = _resolve_optional_path(config.output.directory, base) or config.output.directory
    config.validate()
    return config
