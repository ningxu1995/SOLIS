"""Coordinate reassignment by deterministic interlacing of scan offsets."""

from __future__ import annotations

import numpy as np


def interlace_cycle(
    cycle: np.ndarray,
    address_offsets: list[list[int]] | np.ndarray,
    scan_shape: tuple[int, int] | list[int] = (5, 5),
) -> np.ndarray:
    """Interlace one corrected cycle into a fine grid.

    Parameters
    ----------
    cycle
        Corrected intensity frames with shape (address, y, x).
    address_offsets
        Integer [row, column] offset for each address in acquisition order.
    scan_shape
        Number of reassignment offsets in y and x. For the manuscript this is
        5 x 5, converting the approximately 435 nm camera sampling to 87 nm.
    """
    frames = np.asarray(cycle, dtype=np.float32)
    if frames.ndim != 3:
        raise ValueError(f"cycle must have shape (address, y, x), received {frames.shape}")
    offsets = np.asarray(address_offsets, dtype=int)
    rows, columns = map(int, scan_shape)
    if offsets.shape != (frames.shape[0], 2):
        raise ValueError("address_offsets shape does not match the address axis")

    _, height, width = frames.shape
    output = np.empty((height * rows, width * columns), dtype=np.float32)
    filled = np.zeros((rows, columns), dtype=bool)
    for address, (row_offset, column_offset) in enumerate(offsets):
        if not (0 <= row_offset < rows and 0 <= column_offset < columns):
            raise ValueError(f"Offset {(row_offset, column_offset)} is outside scan_shape")
        if filled[row_offset, column_offset]:
            raise ValueError(f"Duplicate offset {(row_offset, column_offset)}")
        output[row_offset::rows, column_offset::columns] = frames[address]
        filled[row_offset, column_offset] = True
    if not np.all(filled):
        raise ValueError("address_offsets do not cover the complete reassignment lattice")
    return output


def reconstruct_stack(
    corrected_cycles: np.ndarray,
    address_offsets: list[list[int]] | np.ndarray,
    scan_shape: tuple[int, int] | list[int] = (5, 5),
) -> np.ndarray:
    cycles = np.asarray(corrected_cycles)
    if cycles.ndim != 4:
        raise ValueError("corrected_cycles must have shape (cycle, address, y, x)")
    return np.stack(
        [interlace_cycle(cycle, address_offsets, scan_shape) for cycle in cycles],
        axis=0,
    )
