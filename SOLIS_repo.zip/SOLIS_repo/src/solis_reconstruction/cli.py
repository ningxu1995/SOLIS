"""Installed command-line interface."""

from __future__ import annotations

import argparse

from .config import load_config
from .pipeline import reconstruct_file


def main() -> int:
    parser = argparse.ArgumentParser(description="Reconstruct a raw SOLIS sequence")
    parser.add_argument("--config", required=True, help="Path to reconstruction JSON")
    args = parser.parse_args()
    outputs = reconstruct_file(load_config(args.config))
    for name, path in outputs.items():
        print(f"{name}: {path}")
    return 0
