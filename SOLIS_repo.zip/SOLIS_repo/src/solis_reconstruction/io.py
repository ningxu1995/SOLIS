"""Input/output helpers for raw SOLIS sequences and calibration arrays."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import tifffile


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_array(path: str | Path) -> np.ndarray:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".tif", ".tiff"}:
        return np.asarray(tifffile.imread(path))
    if suffix == ".npy":
        return np.load(path, allow_pickle=False)
    if suffix == ".npz":
        with np.load(path, allow_pickle=False) as archive:
            if len(archive.files) != 1:
                raise ValueError(f"{path} must contain exactly one array")
            return np.asarray(archive[archive.files[0]])
    raise ValueError(f"Unsupported array format: {path.suffix}")


def read_raw_stack(path: str | Path, addresses_per_cycle: int) -> np.ndarray:
    """Read raw data as (cycle, address, y, x).

    Accepted TIFF/NumPy shapes are (frame, y, x), where the frame count is a
    multiple of addresses_per_cycle, or (cycle, address, y, x).
    """
    array = read_array(path)
    if array.ndim == 3:
        frames, height, width = array.shape
        if frames % addresses_per_cycle:
            raise ValueError(
                f"Raw frame count {frames} is not divisible by {addresses_per_cycle}"
            )
        return array.reshape(frames // addresses_per_cycle, addresses_per_cycle, height, width)
    if array.ndim == 4:
        if array.shape[1] != addresses_per_cycle:
            raise ValueError(
                f"Address axis has length {array.shape[1]}, expected {addresses_per_cycle}"
            )
        return array
    raise ValueError(f"Raw sequence must be 3D or 4D; received shape {array.shape}")


def read_vector(path: str | Path, expected_length: int) -> np.ndarray:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        values: list[float] = []
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.reader(handle)
            for row in reader:
                if not row:
                    continue
                try:
                    values.append(float(row[-1]))
                except ValueError:
                    continue
        array = np.asarray(values, dtype=np.float32)
    else:
        array = np.ravel(read_array(path)).astype(np.float32)
    if array.size != expected_length:
        raise ValueError(f"{path} contains {array.size} values; expected {expected_length}")
    return array


def read_shifts(path: str | Path, expected_length: int) -> np.ndarray:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        rows: list[list[float]] = []
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            required = {"shift_y_pixels", "shift_x_pixels"}
            if not reader.fieldnames or not required.issubset(reader.fieldnames):
                raise ValueError(f"Shift CSV requires columns {sorted(required)}")
            for row in reader:
                rows.append([float(row["shift_y_pixels"]), float(row["shift_x_pixels"])])
        shifts = np.asarray(rows, dtype=np.float32)
    else:
        shifts = np.asarray(read_array(path), dtype=np.float32)
    if shifts.shape != (expected_length, 2):
        raise ValueError(f"{path} has shape {shifts.shape}; expected {(expected_length, 2)}")
    return shifts


def write_tiff(path: str | Path, stack: np.ndarray, pixel_size_nm: float) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tifffile.imwrite(
        path,
        np.asarray(stack, dtype=np.float32),
        imagej=True,
        metadata={
            "axes": "TYX",
            "unit": "nm",
            "spacing": 1.0,
            "pixel_width": pixel_size_nm,
            "pixel_height": pixel_size_nm,
        },
    )


def write_json(path: str | Path, payload: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
