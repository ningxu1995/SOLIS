"""Preprocessing operations applied before coordinate reassignment."""

from __future__ import annotations

import numpy as np
from scipy.ndimage import shift as ndi_shift


def estimate_border_background(frame: np.ndarray, width: int = 2) -> float:
    if width < 1 or width * 2 >= min(frame.shape):
        raise ValueError("border_width must be positive and smaller than half the frame")
    border = np.concatenate(
        [
            frame[:width, :].ravel(),
            frame[-width:, :].ravel(),
            frame[width:-width, :width].ravel(),
            frame[width:-width, -width:].ravel(),
        ]
    )
    return float(np.median(border))


def preprocess_cycle(
    cycle: np.ndarray,
    *,
    background_mode: str,
    dark_frame: np.ndarray | None = None,
    background_constant: float = 0.0,
    border_width: int = 2,
    flat_field: np.ndarray | None = None,
    address_gains: np.ndarray | None = None,
    address_shifts: np.ndarray | None = None,
    clip_negative: bool = True,
) -> np.ndarray:
    """Correct one cycle with shape (address, y, x)."""
    corrected = np.asarray(cycle, dtype=np.float32).copy()
    addresses, height, width = corrected.shape

    if background_mode == "dark_frame":
        if dark_frame is None:
            raise ValueError("dark_frame is required")
        dark = np.asarray(dark_frame, dtype=np.float32)
        if dark.shape == (height, width):
            corrected -= dark[None, :, :]
        elif dark.shape == corrected.shape:
            corrected -= dark
        else:
            raise ValueError(f"dark_frame has shape {dark.shape}; expected {(height, width)} or {corrected.shape}")
    elif background_mode == "border_median":
        for address in range(addresses):
            corrected[address] -= estimate_border_background(corrected[address], border_width)
    elif background_mode == "constant":
        corrected -= float(background_constant)
    elif background_mode != "none":
        raise ValueError(f"Unknown background mode: {background_mode}")

    if flat_field is not None:
        flat = np.asarray(flat_field, dtype=np.float32)
        if flat.shape != (height, width):
            raise ValueError(f"flat_field has shape {flat.shape}; expected {(height, width)}")
        positive = flat > np.finfo(np.float32).eps
        if not np.all(positive):
            raise ValueError("flat_field contains zero or negative pixels")
        flat = flat / np.mean(flat)
        corrected /= flat[None, :, :]

    if address_gains is not None:
        gains = np.asarray(address_gains, dtype=np.float32)
        if gains.shape != (addresses,):
            raise ValueError(f"address_gains has shape {gains.shape}; expected {(addresses,)}")
        if np.any(gains <= 0):
            raise ValueError("address_gains must be positive")
        gains = gains / np.mean(gains)
        corrected /= gains[:, None, None]

    if address_shifts is not None:
        shifts = np.asarray(address_shifts, dtype=np.float32)
        if shifts.shape != (addresses, 2):
            raise ValueError(f"address_shifts has shape {shifts.shape}; expected {(addresses, 2)}")
        for address, (shift_y, shift_x) in enumerate(shifts):
            corrected[address] = ndi_shift(
                corrected[address],
                shift=(-float(shift_y), -float(shift_x)),
                order=1,
                mode="nearest",
                prefilter=False,
            )

    if clip_negative:
        np.maximum(corrected, 0, out=corrected)
    return corrected
