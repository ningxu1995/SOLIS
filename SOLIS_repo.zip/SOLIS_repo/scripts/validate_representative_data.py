#!/usr/bin/env python3
"""Validate the representative experimental-data manifest."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import tifffile


REQUIRED_COLUMNS = {
    "dataset_id",
    "data_status",
    "relative_path",
    "metadata_path",
    "sha256",
    "manuscript_figures",
    "description",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--addresses-per-cycle", type=int, default=25)
    args = parser.parse_args()

    manifest = Path(args.manifest).resolve()
    root = manifest.parent
    errors: list[str] = []
    with manifest.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not REQUIRED_COLUMNS.issubset(reader.fieldnames):
            missing = REQUIRED_COLUMNS.difference(reader.fieldnames or [])
            raise SystemExit(f"Manifest is missing columns: {sorted(missing)}")
        rows = list(reader)

    if not rows:
        errors.append("manifest contains no representative datasets")

    for line_number, row in enumerate(rows, start=2):
        data_path = (root / row["relative_path"]).resolve()
        metadata_path = (root / row["metadata_path"]).resolve()
        if row["data_status"] != "experimental":
            errors.append(f"line {line_number}: data_status must be experimental")
        if not data_path.exists():
            errors.append(f"line {line_number}: missing data file {data_path}")
            continue
        if not metadata_path.exists():
            errors.append(f"line {line_number}: missing metadata file {metadata_path}")
        else:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            if metadata.get("data_status") != "experimental":
                errors.append(f"line {line_number}: metadata data_status must be experimental")
        actual_hash = sha256(data_path)
        if not row["sha256"]:
            errors.append(f"line {line_number}: sha256 is blank; actual value is {actual_hash}")
        elif row["sha256"].lower() != actual_hash:
            errors.append(f"line {line_number}: SHA-256 mismatch")

        if data_path.suffix.lower() in {".tif", ".tiff"}:
            with tifffile.TiffFile(data_path) as tif:
                shape = tif.series[0].shape
            if len(shape) not in {3, 4}:
                errors.append(f"line {line_number}: TIFF shape {shape} is not a raw sequence")
            elif len(shape) == 3 and shape[0] % args.addresses_per_cycle:
                errors.append(
                    f"line {line_number}: frame count {shape[0]} is not divisible by "
                    f"{args.addresses_per_cycle}"
                )
            elif len(shape) == 4 and shape[1] != args.addresses_per_cycle:
                errors.append(
                    f"line {line_number}: address axis {shape[1]} does not equal "
                    f"{args.addresses_per_cycle}"
                )

    if errors:
        print("Representative-data validation failed:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print(f"Validated {len(rows)} experimental dataset(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
