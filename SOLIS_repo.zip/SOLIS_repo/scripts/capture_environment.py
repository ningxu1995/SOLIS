#!/usr/bin/env python3
"""Record exact runtime versions on the analysis computer."""

from __future__ import annotations

import argparse
from importlib import metadata
import json
from pathlib import Path
import platform
import subprocess
import sys


PACKAGES = ["numpy", "scipy", "tifffile", "pandas", "matplotlib", "seaborn"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="environment")
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    versions = {
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
        "packages": {},
    }
    for package in PACKAGES:
        try:
            versions["packages"][package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            versions["packages"][package] = None
    (output / "runtime_versions.json").write_text(
        json.dumps(versions, indent=2, sort_keys=True), encoding="utf-8"
    )

    freeze = subprocess.run(
        [sys.executable, "-m", "pip", "freeze", "--all"],
        check=True,
        capture_output=True,
        text=True,
    )
    (output / "requirements-lock.txt").write_text(freeze.stdout, encoding="utf-8")
    print(f"Wrote {output / 'runtime_versions.json'}")
    print(f"Wrote {output / 'requirements-lock.txt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
