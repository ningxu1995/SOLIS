#!/usr/bin/env python3
"""Command-line entry point for SOLIS reconstruction."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from solis_reconstruction import load_config, reconstruct_file  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Reconstruct a raw SOLIS sequence")
    parser.add_argument("--config", required=True, help="Path to reconstruction JSON")
    args = parser.parse_args()
    outputs = reconstruct_file(load_config(args.config))
    for name, path in outputs.items():
        print(f"{name}: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
