#!/usr/bin/env python3
"""Create an explicitly synthetic sequence for software testing only."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import tifffile


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="example_data/synthetic_test")
    parser.add_argument("--cycles", type=int, default=4)
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(20260712)
    frames = []
    yy, xx = np.mgrid[:12, :12]
    for cycle in range(args.cycles):
        for address in range(25):
            phase = 2 * np.pi * (cycle * 25 + address) / (args.cycles * 25)
            centre_y = 5.5 + 1.2 * np.sin(phase)
            centre_x = 5.5 + 2.0 * np.cos(phase)
            image = 100 + 1800 * np.exp(-((yy - centre_y) ** 2 + (xx - centre_x) ** 2) / 2.0)
            image += rng.poisson(8, image.shape)
            frames.append(np.clip(image, 0, 65535).astype(np.uint16))
    raw = np.stack(frames)
    tifffile.imwrite(output / "synthetic_raw.tif", raw, photometric="minisblack")
    tifffile.imwrite(output / "dark_frame.tif", np.full((12, 12), 100, dtype=np.uint16))
    tifffile.imwrite(output / "flat_field.tif", np.ones((12, 12), dtype=np.float32))
    np.savetxt(output / "address_gains.csv", np.ones(25), delimiter=",")
    np.savetxt(output / "address_shifts.csv", np.zeros((25, 2)), delimiter=",",
               header="shift_y_pixels,shift_x_pixels", comments="")
    (output / "NOTICE.json").write_text(
        json.dumps(
            {
                "data_status": "synthetic",
                "purpose": "software test only",
                "must_not_be_used_as_experimental_source_data": True,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"Wrote explicitly synthetic test data to {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
