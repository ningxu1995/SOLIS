"""Unit tests for deterministic coordinate reassignment."""

from __future__ import annotations

from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from solis_reconstruction.config import serpentine_offsets  # noqa: E402
from solis_reconstruction.preprocess import preprocess_cycle  # noqa: E402
from solis_reconstruction.reconstruct import interlace_cycle  # noqa: E402


class ReconstructionTests(unittest.TestCase):
    def test_interlace_assigns_each_address_to_calibrated_offset(self) -> None:
        cycle = np.stack([np.full((2, 3), address, dtype=np.float32) for address in range(25)])
        offsets = serpentine_offsets()
        output = interlace_cycle(cycle, offsets, (5, 5))
        self.assertEqual(output.shape, (10, 15))
        for address, (row, column) in enumerate(offsets):
            np.testing.assert_array_equal(output[row::5, column::5], address)

    def test_address_gain_correction(self) -> None:
        gains = np.linspace(0.8, 1.2, 25, dtype=np.float32)
        cycle = gains[:, None, None] * np.ones((25, 2, 2), dtype=np.float32)
        corrected = preprocess_cycle(
            cycle,
            background_mode="none",
            address_gains=gains,
            clip_negative=True,
        )
        np.testing.assert_allclose(corrected, 1.0, rtol=1e-6, atol=1e-6)

    def test_constant_background_and_clipping(self) -> None:
        cycle = np.zeros((25, 2, 2), dtype=np.float32)
        cycle[:, 0, 0] = 7.0
        corrected = preprocess_cycle(
            cycle,
            background_mode="constant",
            background_constant=5.0,
            clip_negative=True,
        )
        self.assertTrue(np.all(corrected[:, 0, 0] == 2.0))
        self.assertTrue(np.all(corrected[:, 1:, :] == 0.0))


if __name__ == "__main__":
    unittest.main()
