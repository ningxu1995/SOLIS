# MATLAB code

Verified optical-design and DMD-pattern scripts should be placed in:

```text
matlab/doe_design/
matlab/dmd_patterns/
```

Each directory should include one small runnable example, documented input
files, and the expected output checksum or summary metric. Historical files
are retained in `matlab/legacy/` because their comments and device terminology
have not yet been reconciled with the submitted manuscript.

Before release, record the MATLAB version and installed toolboxes using `ver`
as described in `docs/ENVIRONMENT.md`.
