# Legacy MATLAB files

These files are retained for provenance but require audit before publication.
In particular, historical comments may refer to an SLM even where the current
manuscript describes DMD addressing. Verified DOE-design and DMD-pattern code
should be placed in `matlab/doe_design/` and `matlab/dmd_patterns/`, with a
minimal runnable example and documented inputs.
