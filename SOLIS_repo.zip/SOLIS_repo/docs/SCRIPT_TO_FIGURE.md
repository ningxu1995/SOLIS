# Script-to-figure map

This map follows manuscript V16 and Supplementary Information V13. `Required`
means the script or source-data file must be added before the repository can be
described as reproducing that panel. Schematics and microscopy images can be
provided as source files without a plotting script, but their raw or minimally
processed data must still be deposited when the panel supports a quantitative
claim.

## Main figures

| Panel | Analysis or source | Expected repository item | Status |
|---|---|---|---|
| Fig. 1a | Representative cilia images and system overview | `source_data/fig1/` plus editable schematic | Required |
| Fig. 1b,c | Optical and sampling schematics | editable vector source | Required |
| Fig. 2a | Optical schematic and DOE SEM | `source_data/fig2/fig2a/` | Required |
| Fig. 2b | DMD address calibration | `python/fig2_address_calibration.py` and coordinate CSV | Required |
| Fig. 2c | Probe images and FWHM profiles | `python/fig2_probe_metrology.py` and raw focal-plane TIFFs | Required |
| Fig. 2d | Empirical contrast transfer | `python/fig2_contrast_transfer.py` and per-region contrast CSV | Required; historical MTF placeholder quarantined |
| Fig. 2e | Line-pair images and profiles | `python/fig2_target_comparison.py` and raw widefield/SOLIS data | Required |
| Fig. 3a | Reconstruction schematic | editable vector source | Required |
| Fig. 3b,d-f | Experimental precision analyses | `python/fig3_experimental_precision.py` and record-level CSV | Required |
| Fig. 3c | Temporal-sampling simulation | `python/fig3_temporal_sampling.py` plus configuration/seed | Implemented; simulation only |
| Fig. 4a-d | Label-free cilia discrimination and sequence | `python/fig4_cilia_sequence.py`, raw sequence, and profiles | Required |
| Fig. 5a-e | Tip tracking and waveform metrics | `python/fig5_waveform_analysis.py` and centroid-level CSV | Required |
| Fig. 6a-c,e | Dynarrestin comparison | `python/fig6_dynarrestin_analysis.py` and dish/field/cluster tables | Required |
| Fig. 6d | Phase-averaged tip waveforms | `python/fig6d_tip_waveforms.py` and processed coordinate table | Implemented; provenance fields still required |

## Supplementary figures

| Panel | Expected repository item | Status |
|---|---|---|
| Supplementary Fig. 1 | `python/suppfig1_conditional_sensitivity.py` | Required |
| Supplementary Fig. 2 | editable optical schematic | Required |
| Supplementary Fig. 3 | `python/suppfig3_probe_metrology.py` and measured metrology CSV | Required; historical synthetic script quarantined |
| Supplementary Fig. 4 | `python/suppfig4_fixed_fluorescence.py` and BPAE source data | Required |
| Supplementary Fig. 5 | `python/suppfig5_live_mitochondria.py` and raw time series | Required |
| Supplementary Fig. 6 | `python/suppfig6_sidelobe_control.py` and configuration | Required |
| Supplementary Fig. 7 | `python/suppfig7_waveform_statistics.py` and per-cilium table | Blocked; supplied phase-precision curves are rescaled post hoc (see audit) |
| Supplementary Fig. 8 | `python/suppfig8_hierarchy_statistics.py` and per-dish table | Required |
| Supplementary Fig. 9 | verified DOE-design code under `matlab/doe_design/` | Required; legacy code retained for audit |

## Core processing

| Output | Code | Status |
|---|---|---|
| Raw 25-address cycles to reassigned maps | `src/solis_reconstruction/` | Implemented |
| Command-line reconstruction | `scripts/reconstruct_sequence.py` | Implemented |
| Raw-sequence validation | `scripts/validate_representative_data.py` | Implemented |
| Representative experimental sequences | `example_data/raw/` and Zenodo | Awaiting real data |
| Environment | `environment.yml`, `requirements.txt`, `pyproject.toml` | Implemented |

## Release rule

Do not mark the repository as fully reproducible until every `Required` entry
used for a quantitative manuscript claim has either a runnable script and
source data or a documented non-code source file. Historical scripts containing
placeholder or interpolated values are excluded from the release workflow.
