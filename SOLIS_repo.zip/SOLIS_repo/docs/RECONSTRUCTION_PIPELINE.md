# SOLIS reconstruction pipeline

## Scope

The pipeline converts original camera frames into coordinate-reassigned SOLIS
maps. It implements the processing sequence described in Methods:

1. group consecutive raw frames into 25-address cycles;
2. subtract a matched dark frame, a fixed background, or a documented border
   estimate;
3. apply detector flat-field correction;
4. correct address-specific probe gains;
5. apply optional measured address-specific registration shifts;
6. assign each corrected frame to its calibrated 5 x 5 offset on the 87 nm
   reconstruction grid;
7. optionally apply a Gaussian filter with sigma = 0.6 reconstructed pixels;
8. write both filtered and unfiltered TIFF stacks, per-cycle QC, configuration,
   software versions, and SHA-256 provenance.

The code performs no deconvolution, regularisation, learning-based restoration,
or generation of unmeasured structure.

## Required raw format

Input is a TIFF, NPY, or single-array NPZ with either:

- `(frame, y, x)`, with frame count divisible by 25; or
- `(cycle, address, y, x)`, with address axis length 25.

The default acquisition order is a row-wise serpentine scan. This must be
replaced in the JSON configuration if the actual DMD acquisition order differs.

## Calibration files

- `dark_frame.tif`: shape `(y, x)` or `(25, y, x)`;
- `flat_field.tif`: shape `(y, x)`, positive values;
- `address_gains.csv`: 25 gains in acquisition order;
- `address_shifts.csv`: columns `shift_y_pixels,shift_x_pixels`.

All calibration files are optional in software but any correction claimed in
the manuscript must be supported by the corresponding deposited calibration.
The example configuration deliberately requires a dark frame.

## Run

```bash
conda env create -f environment.yml
conda activate solis-reproduction
solis-reconstruct --config config/reconstruction.example.json
```

Without installation:

```bash
python scripts/reconstruct_sequence.py \
  --config config/reconstruction.example.json
```

## Output

- `*_reconstructed.tif`: filtered time series;
- `*_reconstructed_unfiltered.tif`: unfiltered reassigned time series;
- `*_qc.csv`: per-cycle intensity and zero-fraction checks;
- `*_metadata.json`: full configuration, file hashes, array shapes, and
  software versions.

## Validation

Run the deterministic unit tests:

```bash
python -m unittest discover -s tests -v
```

The included synthetic-data generator tests software only and is clearly
separated from experimental data:

```bash
python scripts/make_synthetic_test_sequence.py
```

Before release, run the pipeline on every deposited representative raw
sequence and compare the generated output against the corresponding archived
processed image. Record numerical agreement in `docs/VALIDATION_REPORT.md`.
