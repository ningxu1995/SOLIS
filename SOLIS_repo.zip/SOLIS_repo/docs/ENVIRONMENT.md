# Environment and dependency record

`environment.yml` and `requirements.txt` define supported environments. For
the archival release, exact versions from the computer used to generate the
submitted results must also be recorded.

Run in the final analysis environment:

```bash
python scripts/capture_environment.py --output-dir environment
```

Commit the generated:

- `environment/runtime_versions.json`;
- `environment/requirements-lock.txt`.

Record the MATLAB release and toolbox versions by running `ver` in MATLAB and
saving the output as `environment/matlab_ver.txt`. If OS-specific hardware
control code is released, also record the camera, DMD, and CoaXPress driver
versions in `environment/hardware_drivers.txt`.

The supported environment file is not a substitute for the exact lock file.
The lock file must come from the environment that reproduced the final figures.
