# Audit of the July 2026 figure-code additions

Three author-supplied archives were tested before integration.

## Figure 3c

Integrated as `python/fig3_temporal_sampling.py`. The supplied script was
deterministic and explicitly simulation based. Before integration, two model
definitions were corrected and documented:

1. the measured gain factor is now applied per DMD address (`g_n`), rather
   than changing across coarse spatial positions within one address;
2. the 24 fps control is now instantaneous temporal downsampling of the same
   simulated trajectory. It is not exposure-integrated widefield data.

The script now exports the plotted coordinates and a metadata JSON containing
the complete parameters, scan order, and random seed.

## Figure 6d

Integrated as `python/fig6d_tip_waveforms.py` with processed source data in
`source_data/fig6/`. The workbook contains phase-averaged trajectories for
eight control and eight Dynarrestin-treated cilia. It supports Fig. 6d only;
it is not raw camera data and does not reproduce the other Fig. 6 panels.

Culture, field-of-view, and donor or biological-replicate provenance must be
added before archival release.

## Supplementary Figure 7

Not integrated into the formal release workflow. The supplied script first
calculates phase-resolved residual precision from each trajectory and then
multiplies every phase curve by a cilium-specific factor so that its aggregate
value matches `summary.csv`:

```python
scale = (S.localisation_precision_nm.values / my_sig)[:, None]
SP_scaled = SP * scale
```

Those factors are not constant across cilia, so this is not a transparent unit
conversion. The manuscript describes localisation precision as a directly
calculated metric. Formal integration therefore requires one of the following:

1. use one declared residual-based precision calculation throughout and plot
   the directly calculated phase values without rescaling; or
2. deposit the authoritative per-cilium, per-phase precision table produced by
   the method used for `localisation_precision_nm`, then plot that table
   directly.

The supplied `traj.csv` also needs explicit coordinate units and culture,
field-of-view, and biological-replicate provenance. These files are retained
outside the release package pending scientific clarification.
