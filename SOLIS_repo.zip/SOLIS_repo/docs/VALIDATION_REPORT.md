# Validation report

Complete this file before creating the final Zenodo release.

## Software tests

- [ ] `python -m unittest discover -s tests -v` passes in a clean environment.
- [ ] Synthetic test sequence reconstructs without warnings.
- [ ] Output metadata contains raw/calibration SHA-256 hashes.

## Experimental reconstruction checks

For each representative raw sequence, record:

| Dataset ID | Raw shape | Output shape | Archived output compared | Maximum absolute difference | Result |
|---|---:|---:|---|---:|---|
| | | | | | |

## Manuscript consistency

- [ ] Actual acquisition order matches every reconstruction configuration.
- [ ] Address gains are measured rather than nominal.
- [ ] Residual flat-field variation is calculated from deposited calibration.
- [ ] Filtered and unfiltered target/cilia profiles are deposited.
- [ ] Every figure script reads deposited source data and contains no embedded
  experimental values.
- [ ] Figure numbering matches the submitted manuscript and SI.
